# dtcpay CS Portal - UI/UX Design Specification

---

## Table of Contents
1. [Design System](#design-system)
2. [Layout Structure](#layout-structure)
3. [Screen Designs](#screen-designs)
4. [Component Specifications](#component-specifications)
5. [Interaction Patterns](#interaction-patterns)
6. [Responsive Behavior](#responsive-behavior)

---

## 1. Design System

### 1.1 Color Palette

```
Primary Colors:
- Primary Blue:     #0066FF
- Primary Dark:     #0052CC
- Primary Light:    #4D94FF

Status Colors:
- Success:          #00C853
- Warning:          #FFA000
- Error:            #F44336
- Info:             #2196F3

Neutral Colors:
- Gray 900 (Text):  #1A1A1A
- Gray 700:         #424242
- Gray 500:         #757575
- Gray 300:         #BDBDBD
- Gray 100:         #F5F5F5
- White:            #FFFFFF

Background:
- BG Primary:       #FAFAFA
- BG Secondary:     #FFFFFF
- BG Dark:          #1E1E1E (Dark mode)
```

### 1.2 Typography

```
Font Family: 'Inter', sans-serif

Heading 1:  32px, Bold (600), 40px line-height
Heading 2:  24px, Bold (600), 32px line-height
Heading 3:  20px, Semi-bold (600), 28px line-height
Heading 4:  18px, Semi-bold (600), 24px line-height
Body Large: 16px, Regular (400), 24px line-height
Body:       14px, Regular (400), 20px line-height
Body Small: 12px, Regular (400), 18px line-height
Caption:    11px, Regular (400), 16px line-height
```

### 1.3 Spacing Scale

```
xs:  4px
sm:  8px
md:  16px
lg:  24px
xl:  32px
2xl: 48px
3xl: 64px
```

### 1.4 Border Radius

```
Small:  4px
Medium: 8px
Large:  12px
XL:     16px
Round:  50%
```

### 1.5 Shadows

```
sm:  0 1px 2px rgba(0,0,0,0.05)
md:  0 4px 6px rgba(0,0,0,0.07)
lg:  0 10px 15px rgba(0,0,0,0.1)
xl:  0 20px 25px rgba(0,0,0,0.15)
```

---

## 2. Layout Structure

### 2.1 Overall Layout

```
┌─────────────────────────────────────────────────────────────┐
│  Top Navigation Bar (64px height)                           │
│  [Logo] [Search]           [Notifications] [User Profile]   │
├────────┬────────────────────────────────────────────────────┤
│        │                                                     │
│  Side  │                                                     │
│  Nav   │         Main Content Area                          │
│ (240px)│                                                     │
│        │                                                     │
│        │                                                     │
└────────┴────────────────────────────────────────────────────┘

Drawers and modals overlay this structure
```

### 2.2 Top Navigation Bar

```
┌────────────────────────────────────────────────────────────────────┐
│ [☰] dtcpay CS                                                       │
│                                                                      │
│     [🔍 Search by name, email, ID, card...]                         │
│                                                                      │
│                              [🔔 3] [Theme] [👤 Agent Name ▼]       │
└────────────────────────────────────────────────────────────────────┘

Components:
- Hamburger menu (toggle sidebar)
- dtcpay logo + "CS Portal" text
- Global search bar (width: 400px, expandable to 600px on focus)
- Notification bell with badge count
- Theme toggle (light/dark)
- User profile dropdown
```

### 2.3 Sidebar Navigation

```
┌──────────────────────┐
│ dtcpay CS            │
├──────────────────────┤
│                      │
│ 🏠 Dashboard         │
│ 👥 Clients           │ ← Active
│ 📊 Reports           │
│ ⚙️  Settings          │
│                      │
│ ─────────────────    │
│                      │
│ 📌 RECENT CLIENTS    │
│ • John Doe           │
│ • Jane Smith         │
│ • Mike Johnson       │
│                      │
│ [Collapse Sidebar]   │
└──────────────────────┘

Features:
- Collapsible (reduces to icon-only, 64px width)
- Active state highlight
- Recent clients quick access (last 10)
- Fixed position, scrollable
```

---

## 3. Screen Designs

### 3.1 Client Search Results Page

```
┌─────────────────────────────────────────────────────────────────┐
│ Clients                                                          │
│                                                                  │
│ [🔍 Search clients...]                    [+ Add Client]        │
│                                                                  │
│ ┌─────────────────────────────────────────────────────────────┐ │
│ │ Recent Searches                                             │ │
│ │ • John Doe (ID: 12345)  • Jane Smith (ID: 23456)           │ │
│ └─────────────────────────────────────────────────────────────┘ │
│                                                                  │
│ Search Results (3)                                              │
│                                                                  │
│ ┌─────────────────────────────────────────────────────────────┐ │
│ │ [Avatar] John Doe                          🟢 Active        │ │
│ │          ID: 12345 | Tier: Gold                             │ │
│ │          john.doe@email.com | +1234567890                   │ │
│ │          [View Profile →]                                   │ │
│ └─────────────────────────────────────────────────────────────┘ │
│                                                                  │
│ ┌─────────────────────────────────────────────────────────────┐ │
│ │ [Avatar] John Smith                        🟡 Pending KYC   │ │
│ │          ID: 12346 | Tier: Silver                           │ │
│ │          john.smith@email.com | +1234567891                 │ │
│ │          [View Profile →]                                   │ │
│ └─────────────────────────────────────────────────────────────┘ │
│                                                                  │
│ ┌─────────────────────────────────────────────────────────────┐ │
│ │ [Avatar] Johnny Doe                        🔴 Suspended     │ │
│ │          ID: 12347 | Tier: Basic                            │ │
│ │          johnny.d@email.com | +1234567892                   │ │
│ │          [View Profile →]                                   │ │
│ └─────────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────┘
```

---

### 3.2 Client Dashboard Overview

```
┌───────────────────────────────────────────────────────────────────────┐
│ ← Back to Search                                                       │
│                                                                         │
│ ┌───────────────────────────────────────────────────────────────────┐ │
│ │ [Avatar]  John Doe                              🟢 Active          │ │
│ │           ID: 12345                                                │ │
│ │           john.doe@email.com | +1234567890                        │ │
│ │           Member since: Jan 15, 2024                              │ │
│ │                                                                    │ │
│ │  [📧 Contact] [📄 Export] [⚡ Quick Actions ▼]                    │ │
│ └───────────────────────────────────────────────────────────────────┘ │
│                                                                         │
│ ┌──────────────┬──────────────┬──────────────┬──────────────────────┐ │
│ │   💳 Cards    │ 💰 Balance    │ 🏆 Tier       │ 📊 Onboarding       │ │
│ │      3        │  $12,450.50  │    Gold      │   Completed         │ │
│ │    Active     │  5 Currencies│   Premium    │   ✓ Verified        │ │
│ └──────────────┴──────────────┴──────────────┴──────────────────────┘ │
│                                                                         │
│ ┌─────────────────────────────────────────────────────────────────┐   │
│ │ 🔍 Quick Overview Tabs                                          │   │
│ │ [Profile] [Account] [Onboarding] [Transactions] [Wallets]      │   │
│ │ [Cards] [Security] [Audit Log]                                  │   │
│ └─────────────────────────────────────────────────────────────────┘   │
│                                                                         │
│ ┌─────────────────────────────┐ ┌─────────────────────────────────┐   │
│ │ 📈 Recent Activity          │ │ ⚠️  Alerts & Notifications      │   │
│ │                             │ │                                 │   │
│ │ • Deposit $500              │ │ • 3 failed login attempts       │   │
│ │   2 hours ago               │ │   from new IP (Flagged)         │   │
│ │                             │ │                                 │   │
│ │ • Card transaction          │ │ • Card expiring in 30 days      │   │
│ │   $125.00 - Amazon          │ │   Card ****4523                 │   │
│ │   5 hours ago               │ │                                 │   │
│ │                             │ │ [View All Alerts →]             │   │
│ │ • Withdrew $200             │ │                                 │   │
│ │   1 day ago                 │ │                                 │   │
│ │                             │ │                                 │   │
│ │ [View All →]                │ │                                 │   │
│ └─────────────────────────────┘ └─────────────────────────────────┘   │
│                                                                         │
│ ┌─────────────────────────────────────────────────────────────────┐   │
│ │ 📝 CS Notes                                          [+ Add Note] │   │
│ │                                                                   │   │
│ │ 2026-01-15 10:30 AM - Agent Sarah                                │   │
│ │ "Client called regarding card delivery. Provided tracking #..."  │   │
│ │                                                                   │   │
│ │ 2026-01-10 02:15 PM - Agent Mike                                 │   │
│ │ "Helped client reset 2FA after phone change"                     │   │
│ └─────────────────────────────────────────────────────────────────┘   │
└───────────────────────────────────────────────────────────────────────┘
```

---

### 3.3 Profile Tab - Personal Information

```
┌───────────────────────────────────────────────────────────────────┐
│ Profile                                         [✏️ Edit Profile]  │
├───────────────────────────────────────────────────────────────────┤
│                                                                    │
│ Personal Information                                               │
│ ┌────────────────────────────────────────────────────────────────┐│
│ │ Full Name:              John Michael Doe                       ││
│ │ Date of Birth:          March 15, 1990 (35 years old)          ││
│ │ Nationality:            🇺🇸 United States                       ││
│ │ Country of Residence:   🇺🇸 United States                       ││
│ │ Tax Residency:          United States                          ││
│ │ Preferred Language:     English                                ││
│ └────────────────────────────────────────────────────────────────┘│
│                                                                    │
│ Contact Information                                                │
│ ┌────────────────────────────────────────────────────────────────┐│
│ │ Email:                  john.doe@email.com       ✓ Verified    ││
│ │ Phone:                  +1 (234) 567-8900        ✓ Verified    ││
│ │ Alternative Phone:      +1 (234) 567-8901                      ││
│ └────────────────────────────────────────────────────────────────┘│
│                                                                    │
│ Address Information                                                │
│ ┌────────────────────────────────────────────────────────────────┐│
│ │ Current Address:                                               ││
│ │ 123 Main Street, Apt 4B                                        ││
│ │ New York, NY 10001                                             ││
│ │ United States                                                  ││
│ │                                                                ││
│ │ Address Verified: ✓ Yes (Document uploaded 2024-01-15)        ││
│ │ [View Verification Document →]                                 ││
│ │                                                                ││
│ │ Previous Addresses: [View History →]                           ││
│ └────────────────────────────────────────────────────────────────┘│
│                                                                    │
│ [View Change History →]                                            │
└───────────────────────────────────────────────────────────────────┘
```

**Edit Profile Modal (When clicked):**
```
┌─────────────────────────────────────────────────────────┐
│ ✕ Edit Client Information                               │
├─────────────────────────────────────────────────────────┤
│                                                          │
│ ⚠️  Changes will be logged in audit trail                │
│                                                          │
│ Full Name:                                               │
│ [John Michael Doe___________________________]            │
│                                                          │
│ Date of Birth:                                           │
│ [03/15/1990_] 📅                                         │
│                                                          │
│ Nationality:                                             │
│ [United States ▼]                                        │
│                                                          │
│ Country of Residence:                                    │
│ [United States ▼]                                        │
│                                                          │
│ Phone:                                                   │
│ [+1 234 567 8900_____________________]                   │
│                                                          │
│ Reason for Change: *                                     │
│ [Select reason ▼]                                        │
│ • Client request                                         │
│ • Data correction                                        │
│ • Document update                                        │
│ • Other                                                  │
│                                                          │
│ Additional Notes:                                        │
│ [________________________________]                       │
│ [________________________________]                       │
│                                                          │
│                            [Cancel]  [Save Changes]      │
└─────────────────────────────────────────────────────────┘
```

---

### 3.4 Account Tab

```
┌───────────────────────────────────────────────────────────────────┐
│ Account Information                            [⚙️ Manage Account] │
├───────────────────────────────────────────────────────────────────┤
│                                                                    │
│ Account Status                                                     │
│ ┌────────────────────────────────────────────────────────────────┐│
│ │ Account ID:            ACC-12345-US                            ││
│ │ Status:                🟢 Active                               ││
│ │ Account Type:          Individual (B2C)                        ││
│ │ Opening Date:          January 15, 2024                        ││
│ │ Last Activity:         2 hours ago                             ││
│ │ KYC Status:            ✓ Verified (Level 3)                    ││
│ │ AML Risk Score:        Low (Score: 15/100)                     ││
│ └────────────────────────────────────────────────────────────────┘│
│                                                                    │
│ Account Tier & Benefits                      [🔼 Change Tier →]   │
│ ┌────────────────────────────────────────────────────────────────┐│
│ │ Current Tier:          🏆 Gold                                 ││
│ │ Since:                 March 1, 2024                           ││
│ │                                                                ││
│ │ Benefits:                                                      ││
│ │ ✓ Premium support                                              ││
│ │ ✓ Higher transaction limits ($50,000/day)                     ││
│ │ ✓ Reduced fees (0.5% on swaps)                                ││
│ │ ✓ Priority card delivery                                       ││
│ │ ✓ 3 free international transfers/month                        ││
│ │                                                                ││
│ │ Eligible for Platinum: ⚠️  $25,000 more to reach              ││
│ │ [View Tier Comparison →]                                       ││
│ └────────────────────────────────────────────────────────────────┘│
│                                                                    │
│ Pricing & Fees                                [📝 Modify Pricing]  │
│ ┌────────────────────────────────────────────────────────────────┐│
│ │ Pricing Plan:          Gold Standard                           ││
│ │                                                                ││
│ │ Fee Structure:                                                 ││
│ │ • Deposits:            Free                                    ││
│ │ • Withdrawals:         0.5% (Min $2.00)                        ││
│ │ • Currency Swap:       0.5%                                    ││
│ │ • International:       1.0% + $5.00                            ││
│ │ • Card Transaction:    Free domestic, 2% international         ││
│ │ • Monthly Fee:         $9.99 (waived with $5k balance)         ││
│ │                                                                ││
│ │ Transaction Limits:                                            ││
│ │ • Daily:               $50,000                                 ││
│ │ • Monthly:             $500,000                                ││
│ │ • Per Transaction:     $25,000                                 ││
│ └────────────────────────────────────────────────────────────────┘│
│                                                                    │
│ Affiliation & Tags                              [🏷️ Manage Tags]  │
│ ┌────────────────────────────────────────────────────────────────┐│
│ │ Referral Source:       Partner-ABC (Code: REF123)              ││
│ │ Campaign:              Q1-2024-Premium                          ││
│ │ Customer Tags:         [VIP] [Early Adopter] [Corporate]       ││
│ │                                                                ││
│ │ Account Manager:       Sarah Johnson                           ││
│ │ Relationship:          3 referrals made                        ││
│ └────────────────────────────────────────────────────────────────┘│
│                                                                    │
│ [View Status History →]                                            │
└───────────────────────────────────────────────────────────────────┘
```

---

### 3.5 Onboarding Status Tab

```
┌───────────────────────────────────────────────────────────────────┐
│ Onboarding Status                                                  │
├───────────────────────────────────────────────────────────────────┤
│                                                                    │
│ Overall Progress: 100% Complete ✓                                 │
│                                                                    │
│ ┌────────────────────────────────────────────────────────────────┐│
│ │                                                                ││
│ │  ✓────✓────✓────✓────✓────✓────✓────✓                         ││
│ │  1    2    3    4    5    6    7    8                         ││
│ │                                                                ││
│ └────────────────────────────────────────────────────────────────┘│
│                                                                    │
│ ┌────────────────────────────────────────────────────────────────┐│
│ │ ✓ 1. Registration Complete                                     ││
│ │   Completed: Jan 15, 2024 10:30 AM                            ││
│ │   Email: john.doe@email.com                                    ││
│ │   [View Details ↓]                                             ││
│ └────────────────────────────────────────────────────────────────┘│
│                                                                    │
│ ┌────────────────────────────────────────────────────────────────┐│
│ │ ✓ 2. Email Verification                                        ││
│ │   Completed: Jan 15, 2024 10:35 AM                            ││
│ │   Verified within 5 minutes                                    ││
│ └────────────────────────────────────────────────────────────────┘│
│                                                                    │
│ ┌────────────────────────────────────────────────────────────────┐│
│ │ ✓ 3. Phone Verification                                        ││
│ │   Completed: Jan 15, 2024 10:42 AM                            ││
│ │   Phone: +1 234 567 8900                                       ││
│ │   Method: SMS Code                                             ││
│ └────────────────────────────────────────────────────────────────┘│
│                                                                    │
│ ┌────────────────────────────────────────────────────────────────┐│
│ │ ✓ 4. KYC Document Upload                                       ││
│ │   Completed: Jan 15, 2024 11:15 AM                            ││
│ │   Documents:                                                   ││
│ │   • Passport (USA) - [View 👁️]                                 ││
│ │   • Proof of Address (Utility Bill) - [View 👁️]               ││
│ │   [Request Re-upload]                                          ││
│ └────────────────────────────────────────────────────────────────┘│
│                                                                    │
│ ┌────────────────────────────────────────────────────────────────┐│
│ │ ✓ 5. KYC Document Review                                       ││
│ │   Completed: Jan 16, 2024 09:20 AM                            ││
│ │   Reviewed by: Agent Sarah                                     ││
│ │   Result: Approved                                             ││
│ │   Risk Score: Low                                              ││
│ │   [View Review Notes →]                                        ││
│ └────────────────────────────────────────────────────────────────┘│
│                                                                    │
│ ┌────────────────────────────────────────────────────────────────┐│
│ │ ✓ 6. Address Verification                                      ││
│ │   Completed: Jan 16, 2024 09:20 AM                            ││
│ │   Method: Document verification                                ││
│ │   Address: 123 Main St, Apt 4B, New York, NY 10001           ││
│ └────────────────────────────────────────────────────────────────┘│
│                                                                    │
│ ┌────────────────────────────────────────────────────────────────┐│
│ │ ✓ 7. Account Approved                                          ││
│ │   Completed: Jan 16, 2024 09:25 AM                            ││
│ │   Auto-approved based on risk assessment                       ││
│ │   Account Status: Active                                       ││
│ │   KYC Level: 3 (Full Verification)                            ││
│ └────────────────────────────────────────────────────────────────┘│
│                                                                    │
│ ┌────────────────────────────────────────────────────────────────┐│
│ │ ✓ 8. First Deposit                                             ││
│ │   Completed: Jan 16, 2024 02:30 PM                            ││
│ │   Amount: $1,000.00 USD                                        ││
│ │   Method: Bank Transfer                                        ││
│ │   [View Transaction →]                                         ││
│ └────────────────────────────────────────────────────────────────┘│
│                                                                    │
│ ┌────────────────────────────────────────────────────────────────┐│
│ │ 📝 CS Notes & Actions                                          ││
│ │                                                                ││
│ │ [+ Add Note]  [📧 Send Reminder]  [🚨 Escalate]               ││
│ │                                                                ││
│ │ No issues or notes recorded                                    ││
│ └────────────────────────────────────────────────────────────────┘│
└───────────────────────────────────────────────────────────────────┘
```

**Example - Incomplete Onboarding with Blocker:**

```
┌───────────────────────────────────────────────────────────────────┐
│ Onboarding Status                                                  │
├───────────────────────────────────────────────────────────────────┤
│                                                                    │
│ Overall Progress: 62% Complete ⚠️                                  │
│ Est. Time to Complete: Action Required                            │
│                                                                    │
│ ┌────────────────────────────────────────────────────────────────┐│
│ │                                                                ││
│ │  ✓────✓────✓────✓────🔴───○────○────○                         ││
│ │  1    2    3    4    5    6    7    8                         ││
│ │                    BLOCKED                                     ││
│ │                                                                ││
│ └────────────────────────────────────────────────────────────────┘│
│                                                                    │
│ [Steps 1-4 collapsed, showing as complete]                        │
│                                                                    │
│ ┌────────────────────────────────────────────────────────────────┐│
│ │ 🔴 5. KYC Document Review                   ⚠️  ACTION NEEDED  ││
│ │   Status: Rejected                                             ││
│ │   Updated: Jan 16, 2024 09:20 AM (3 days ago)                 ││
│ │                                                                ││
│ │   ⚠️  BLOCKER: Address proof document unclear                  ││
│ │                                                                ││
│ │   Rejection Reason:                                            ││
│ │   "The utility bill provided is more than 3 months old.       ││
│ │   Please provide a recent proof of address document dated     ││
│ │   within the last 90 days."                                    ││
│ │                                                                ││
│ │   Reviewed by: Agent Mike                                      ││
│ │   Review Date: Jan 16, 2024 09:20 AM                          ││
│ │                                                                ││
│ │   📎 Current Document: utility_bill.pdf [View 👁️]              ││
│ │      Uploaded: Jan 15, 2024 11:15 AM                          ││
│ │      Date on Document: September 10, 2023 ⚠️                   ││
│ │                                                                ││
│ │   [Request Re-upload] [Send Reminder Email] [Call Client]     ││
│ │   [Escalate to KYC Team] [Add Note]                           ││
│ └────────────────────────────────────────────────────────────────┘│
│                                                                    │
│ ┌────────────────────────────────────────────────────────────────┐│
│ │ 📝 CS Notes & Actions                                          ││
│ │                                                                ││
│ │ Jan 18, 2024 10:00 AM - Agent Sarah                           ││
│ │ "Sent reminder email to client about updating address proof.  ││
│ │ Explained requirements clearly. Awaiting response."           ││
│ │                                                                ││
│ │ Jan 16, 2024 09:25 AM - Agent Mike                            ││
│ │ "Document rejected - date too old. Need recent utility bill." ││
│ │                                                                ││
│ │ [+ Add New Note]                                               ││
│ └────────────────────────────────────────────────────────────────┘│
└───────────────────────────────────────────────────────────────────┘
```

---

### 3.6 Transactions Tab

```
┌───────────────────────────────────────────────────────────────────┐
│ Transaction History                                   [Export ↓]   │
├───────────────────────────────────────────────────────────────────┤
│                                                                    │
│ Filters:                                                           │
│ [Type: All ▼] [Status: All ▼] [Currency: All ▼]                  │
│ [Date: Last 30 Days ▼] [Amount: Any ▼]          [Reset] [Apply]  │
│                                                                    │
│ ┌────────────────────────────────────────────────────────────────┐│
│ │ 152 transactions found                  Showing 1-50 of 152    ││
│ └────────────────────────────────────────────────────────────────┘│
│                                                                    │
│ ┌────────────────────────────────────────────────────────────────┐│
│ │ ↓ Deposit                                  ✓ Completed         ││
│ │ TXN-456789                                                     ││
│ │ +$500.00 USD                                                   ││
│ │ Jan 19, 2026 10:30 AM                                         ││
│ │ Bank Transfer • Wells Fargo ****1234                           ││
│ │ [View Details →]                                               ││
│ └────────────────────────────────────────────────────────────────┘│
│                                                                    │
│ ┌────────────────────────────────────────────────────────────────┐│
│ │ 💳 Card Payment                             ✓ Completed         ││
│ │ TXN-456788                                                     ││
│ │ -$125.50 USD                                                   ││
│ │ Jan 18, 2026 03:15 PM                                         ││
│ │ Amazon.com • Card ****4523                                     ││
│ │ [View Details →]                                               ││
│ └────────────────────────────────────────────────────────────────┘│
│                                                                    │
│ ┌────────────────────────────────────────────────────────────────┐│
│ │ 🔄 Swap                                     ⏳ Processing        ││
│ │ TXN-456787                                                     ││
│ │ 0.5 BTC → $30,250.00 USD                                      ││
│ │ Jan 18, 2026 11:20 AM                                         ││
│ │ Rate: 1 BTC = $60,500 USD • Fee: $151.25                     ││
│ │ [View Details →]                                               ││
│ └────────────────────────────────────────────────────────────────┘│
│                                                                    │
│ ┌────────────────────────────────────────────────────────────────┐│
│ │ ↑ Withdrawal                                ❌ Failed           ││
│ │ TXN-456786                                                     ││
│ │ -$1,000.00 USD                                                 ││
│ │ Jan 17, 2026 09:45 AM                                         ││
│ │ Bank Transfer • Failed: Insufficient Balance                   ││
│ │ [View Details →]                                               ││
│ └────────────────────────────────────────────────────────────────┘│
│                                                                    │
│ [Load More...]                                    [1][2][3]...    │
└───────────────────────────────────────────────────────────────────┘
```

**Transaction Details Drawer (Right Side):**

```
                                      ┌─────────────────────────────┐
                                      │ ✕ Transaction Details       │
                                      ├─────────────────────────────┤
                                      │                             │
                                      │ Transaction ID              │
                                      │ TXN-456789   [Copy 📋]      │
                                      │                             │
                                      │ Status: ✓ Completed         │
                                      │                             │
                                      │ ┌─────────────────────────┐ │
                                      │ │ Type: Deposit           │ │
                                      │ │ Amount: $500.00 USD     │ │
                                      │ │ Fee: $0.00              │ │
                                      │ │ Net: $500.00            │ │
                                      │ └─────────────────────────┘ │
                                      │                             │
                                      │ From                        │
                                      │ Wells Fargo Bank            │
                                      │ Account: ****1234           │
                                      │ Name: John Doe              │
                                      │                             │
                                      │ To                          │
                                      │ dtcpay USD Wallet           │
                                      │ Account: John Doe           │
                                      │                             │
                                      │ Timeline                    │
                                      │ ┌─────────────────────────┐ │
                                      │ │ ✓ Created               │ │
                                      │ │   Jan 19, 10:30:15 AM   │ │
                                      │ │                         │ │
                                      │ │ ✓ Processing            │ │
                                      │ │   Jan 19, 10:30:20 AM   │ │
                                      │ │                         │ │
                                      │ │ ✓ Bank Confirmed        │ │
                                      │ │   Jan 19, 10:32:45 AM   │ │
                                      │ │                         │ │
                                      │ │ ✓ Completed             │ │
                                      │ │   Jan 19, 10:33:00 AM   │ │
                                      │ └─────────────────────────┘ │
                                      │                             │
                                      │ Risk Assessment             │
                                      │ Score: Low (12/100)         │
                                      │ No flags detected           │
                                      │                             │
                                      │ Related Transactions        │
                                      │ None                        │
                                      │                             │
                                      │ ─────────────────           │
                                      │                             │
                                      │ 📝 CS Notes                 │
                                      │ [+ Add Note]                │
                                      │                             │
                                      │ No notes yet                │
                                      │                             │
                                      │ ─────────────────           │
                                      │                             │
                                      │ Actions                     │
                                      │ [🔄 Refund]                 │
                                      │ [❌ Cancel]                 │
                                      │ [🚨 Flag as Suspicious]     │
                                      │ [📧 Send Receipt]           │
                                      │                             │
                                      │ [Close]                     │
                                      └─────────────────────────────┘
```

---

### 3.7 Wallets Tab

```
┌───────────────────────────────────────────────────────────────────┐
│ Wallet Balances                                                    │
├───────────────────────────────────────────────────────────────────┤
│                                                                    │
│ ┌────────────────────────────────────────────────────────────────┐│
│ │ Total Portfolio Value                                          ││
│ │ $12,450.50 USD                                                 ││
│ │ +$245.30 (+2.01%) today                                        ││
│ └────────────────────────────────────────────────────────────────┘│
│                                                                    │
│ [Fiat] [Crypto] [All]                                             │
│                                                                    │
│ ┌────────────────────────────────────────────────────────────────┐│
│ │ 💵 USD - US Dollar                         [View History →]    ││
│ │                                                                ││
│ │ Balance: $5,250.00                                             ││
│ │ Available: $5,250.00 | Locked: $0.00                          ││
│ │                                                                ││
│ │ 24h Change: +$125.00 (+2.4%)  ────────────────/─────          ││
│ │ 7d Change:  +$320.00 (+6.5%)                                  ││
│ │ 30d Change: +$750.00 (+16.7%)                                 ││
│ │                                                                ││
│ │ [Manual Adjust] [View Transactions]                            ││
│ └────────────────────────────────────────────────────────────────┘│
│                                                                    │
│ ┌────────────────────────────────────────────────────────────────┐│
│ │ 💶 EUR - Euro                              [View History →]    ││
│ │                                                                ││
│ │ Balance: €2,100.00 (~$2,289.00 USD)                           ││
│ │ Available: €2,100.00 | Locked: €0.00                          ││
│ │                                                                ││
│ │ 24h Change: €0.00 (0%)        ─────────────────────────       ││
│ │ 7d Change:  -€50.00 (-2.3%)                                   ││
│ │ 30d Change: +€200.00 (+10.5%)                                 ││
│ │                                                                ││
│ │ [Manual Adjust] [View Transactions]                            ││
│ └────────────────────────────────────────────────────────────────┘│
│                                                                    │
│ ┌────────────────────────────────────────────────────────────────┐│
│ │ ₿ BTC - Bitcoin                            [View History →]    ││
│ │                                                                ││
│ │ Balance: 0.08352645 BTC (~$5,053.85 USD)                      ││
│ │ Available: 0.08352645 BTC | Locked: 0.00 BTC                  ││
│ │                                                                ││
│ │ 24h Change: +0.0005 BTC (+0.6%)  ────────────/────            ││
│ │ 7d Change:  +0.002 BTC (+2.5%)                                ││
│ │ 30d Change: +0.01 BTC (+13.6%)                                ││
│ │                                                                ││
│ │ [Manual Adjust] [View Transactions]                            ││
│ └────────────────────────────────────────────────────────────────┘│
│                                                                    │
│ [+ More currencies...]                                             │
└───────────────────────────────────────────────────────────────────┘
```

**Balance History Side Panel (Slides from right):**

```
                              ┌───────────────────────────────────────┐
                              │ ← USD Balance History                 │
                              ├───────────────────────────────────────┤
                              │                                       │
                              │ Current Balance: $5,250.00            │
                              │                                       │
                              │ Date Range: [Last 30 Days ▼]         │
                              │                                       │
                              │ ┌───────────────────────────────────┐ │
                              │ │        📈 Balance Chart           │ │
                              │ │                                   │ │
                              │ │         /─────/                   │ │
                              │ │      /─/     \                    │ │
                              │ │   /─/         \                   │ │
                              │ │ /─              ──                │ │
                              │ │                                   │ │
                              │ │ Jan 1        Jan 15      Jan 30   │ │
                              │ └───────────────────────────────────┘ │
                              │                                       │
                              │ Timeline                              │
                              │ ┌───────────────────────────────────┐ │
                              │ │ Jan 19, 10:30 AM                  │ │
                              │ │ +$500.00                          │ │
                              │ │ Deposit from Wells Fargo          │ │
                              │ │ Balance: $5,250.00                │ │
                              │ │ [TXN-456789 →]                    │ │
                              │ ├───────────────────────────────────┤ │
                              │ │ Jan 18, 03:15 PM                  │ │
                              │ │ -$125.50                          │ │
                              │ │ Card Payment - Amazon             │ │
                              │ │ Balance: $4,750.00                │ │
                              │ │ [TXN-456788 →]                    │ │
                              │ ├───────────────────────────────────┤ │
                              │ │ Jan 17, 02:00 PM                  │ │
                              │ │ +$30,250.00                       │ │
                              │ │ BTC Swap (0.5 BTC sold)           │ │
                              │ │ Balance: $4,875.50                │ │
                              │ │ [TXN-456787 →]                    │ │
                              │ └───────────────────────────────────┘ │
                              │                                       │
                              │ [Load More...]                        │
                              │                                       │
                              │ [Export CSV] [Close]                  │
                              └───────────────────────────────────────┘
```

**Manual Balance Adjustment Modal:**

```
┌──────────────────────────────────────────────────┐
│ ⚠️  Manual Balance Adjustment                     │
├──────────────────────────────────────────────────┤
│                                                   │
│ Currency: USD                                     │
│ Current Balance: $5,250.00                        │
│                                                   │
│ ⚠️  This action requires manager approval and      │
│ will be logged in audit trail                    │
│                                                   │
│ Adjustment Type:                                  │
│ ○ Add funds                                       │
│ ● Subtract funds                                  │
│ ○ Set exact balance                               │
│                                                   │
│ Amount:                                           │
│ [$ ______________.___]                            │
│                                                   │
│ New Balance: $____________                        │
│                                                   │
│ Reason: *                                         │
│ [Select reason ▼]                                 │
│ • Reconciliation                                  │
│ • Error correction                                │
│ • Refund                                          │
│ • Compensation                                    │
│ • Other                                           │
│                                                   │
│ Detailed Explanation: *                           │
│ [_____________________________________]           │
│ [_____________________________________]           │
│ [_____________________________________]           │
│                                                   │
│ Reference Transaction ID (if applicable):         │
│ [_____________________________________]           │
│                                                   │
│ Approval Required:                                │
│ Manager: [Select Manager ▼]                       │
│                                                   │
│ ☐ Send notification to client                    │
│                                                   │
│                      [Cancel]  [Submit Request]   │
└──────────────────────────────────────────────────┘
```

---

### 3.8 Cards Tab

```
┌───────────────────────────────────────────────────────────────────┐
│ Cards                                             [+ Request Card]  │
├───────────────────────────────────────────────────────────────────┤
│                                                                    │
│ ┌──────────────────────┐  ┌──────────────────────┐               │
│ │  💳                  │  │  💳                  │               │
│ │                      │  │                      │               │
│ │  **** **** **** 4523 │  │  **** **** **** 8821 │               │
│ │                      │  │                      │               │
│ │  JOHN DOE            │  │  JOHN DOE            │               │
│ │  VALID THRU 12/27    │  │  VALID THRU 08/26    │               │
│ │                      │  │                      │               │
│ │  🟢 Active           │  │  🔵 Frozen           │               │
│ │  Physical Card       │  │  Virtual Card        │               │
│ │  Balance: $2,450.00  │  │  Balance: $500.00    │               │
│ │                      │  │                      │               │
│ │  [View Details →]    │  │  [View Details →]    │               │
│ └──────────────────────┘  └──────────────────────┘               │
│                                                                    │
│ ┌──────────────────────┐                                          │
│ │  💳                  │                                          │
│ │                      │                                          │
│ │  **** **** **** ****  │                                          │
│ │                      │                                          │
│ │  JOHN DOE            │                                          │
│ │  APPLICATION PENDING │                                          │
│ │                      │                                          │
│ │  ⏳ Under Application│                                          │
│ │  Physical Card       │                                          │
│ │  Expected: Jan 25    │                                          │
│ │                      │                                          │
│ │  [View Status →]     │                                          │
│ └──────────────────────┘                                          │
│                                                                    │
└───────────────────────────────────────────────────────────────────┘
```

**Card Details Drawer (Active Card):**

```
                                      ┌─────────────────────────────┐
                                      │ ✕ Card Details              │
                                      ├─────────────────────────────┤
                                      │                             │
                                      │ ┌─────────────────────────┐ │
                                      │ │  💳 dtcpay Card         │ │
                                      │ │                         │ │
                                      │ │  [Click to reveal]      │ │
                                      │ │  **** **** **** 4523    │ │
                                      │ │                         │ │
                                      │ │  JOHN DOE               │ │
                                      │ │  VALID THRU 12/27       │ │
                                      │ │  CVV: *** [Reveal 👁️]   │ │
                                      │ └─────────────────────────┘ │
                                      │                             │
                                      │ Status: 🟢 Active           │
                                      │ Card Type: Physical Card    │
                                      │                             │
                                      │ Card Information            │
                                      │ ┌─────────────────────────┐ │
                                      │ │ Card Number:            │ │
                                      │ │ **** **** **** 4523     │ │
                                      │ │ [Reveal Full] [Copy]    │ │
                                      │ │                         │ │
                                      │ │ Cardholder: John Doe    │ │
                                      │ │ Issue Date: 06/15/2024  │ │
                                      │ │ Expiry Date: 12/31/2027 │ │
                                      │ │ Card Balance: $2,450.00 │ │
                                      │ │ Available: $2,450.00    │ │
                                      │ └─────────────────────────┘ │
                                      │                             │
                                      │ Card Limits                 │
                                      │ ┌─────────────────────────┐ │
                                      │ │ Daily Limit: $5,000     │ │
                                      │ │ Used Today: $125.50     │ │
                                      │ │ Remaining: $4,874.50    │ │
                                      │ │                         │ │
                                      │ │ Monthly Limit: $50,000  │ │
                                      │ │ Used: $3,450.50         │ │
                                      │ │ Remaining: $46,549.50   │ │
                                      │ └─────────────────────────┘ │
                                      │                             │
                                      │ Delivery Information        │
                                      │ ┌─────────────────────────┐ │
                                      │ │ Delivered: ✓ Yes        │ │
                                      │ │ Date: June 20, 2024     │ │
                                      │ │ Address:                │ │
                                      │ │ 123 Main Street, Apt 4B │ │
                                      │ │ New York, NY 10001      │ │
                                      │ │ United States           │ │
                                      │ │                         │ │
                                      │ │ Tracking: 1Z999AA...    │ │
                                      │ │ [Copy] [Track Package]  │ │
                                      │ └─────────────────────────┘ │
                                      │                             │
                                      │ ─────────────────           │
                                      │                             │
                                      │ Card Actions                │
                                      │ [❄️ Freeze Card]            │
                                      │ [🔄 Replace Card]           │
                                      │ [📍 Update Address]         │
                                      │ [❌ Cancel Card]            │
                                      │                             │
                                      │ ─────────────────           │
                                      │                             │
                                      │ [View Transactions]         │
                                      │                             │
                                      │ [Close]                     │
                                      └─────────────────────────────┘
```

**Freeze Card Confirmation Modal:**

```
┌──────────────────────────────────────────────────┐
│ ❄️ Freeze Card                                    │
├──────────────────────────────────────────────────┤
│                                                   │
│ Card: **** **** **** 4523                         │
│                                                   │
│ ⚠️  Freezing this card will:                      │
│                                                   │
│ • Immediately block all transactions             │
│ • Decline any pending authorizations             │
│ • Keep the card number active (can be unfrozen)  │
│ • Log this action in audit trail                 │
│                                                   │
│ The client will be notified via email and app.   │
│                                                   │
│ Reason for Freezing: *                            │
│ [Select reason ▼]                                 │
│ • Lost card                                       │
│ • Stolen card                                     │
│ • Suspicious activity                             │
│ • Customer request                                │
│ • Other                                           │
│                                                   │
│ Additional Notes:                                 │
│ [_____________________________________]           │
│ [_____________________________________]           │
│                                                   │
│ ☑ Send notification to client                    │
│ ☐ Auto-order replacement card                    │
│                                                   │
│                          [Cancel]  [Freeze Card]  │
└──────────────────────────────────────────────────┘
```

**Replace Card Modal:**

```
┌──────────────────────────────────────────────────┐
│ 🔄 Replace Card                                   │
├──────────────────────────────────────────────────┤
│                                                   │
│ Current Card: **** **** **** 4523                 │
│                                                   │
│ Replacement Reason: *                             │
│ ○ Lost                                            │
│ ○ Stolen                                          │
│ ● Damaged                                         │
│ ○ Expired                                         │
│ ○ Compromised                                     │
│                                                   │
│ Replacement Type:                                 │
│ ● Same card number (for damaged/expired)         │
│ ○ New card number (for lost/stolen/compromised)  │
│                                                   │
│ Delivery Address: *                               │
│ ● Use registered address                         │
│   123 Main Street, Apt 4B                        │
│   New York, NY 10001                             │
│                                                   │
│ ○ Use different address                          │
│   [Street Address________________]               │
│   [City________] [State__] [Zip____]             │
│                                                   │
│ Delivery Method:                                  │
│ ● Standard (5-7 business days) - Free            │
│ ○ Express (2-3 business days) - $25              │
│ ○ Overnight (1 business day) - $50               │
│                                                   │
│ Current Card Action:                              │
│ ● Freeze immediately, cancel upon delivery       │
│ ○ Keep active until replacement arrives          │
│                                                   │
│ ☑ Send tracking information to client            │
│ ☑ Email replacement confirmation                 │
│                                                   │
│                      [Cancel]  [Order Replacement]│
└──────────────────────────────────────────────────┘
```

**Card Transactions Tab (Within Drawer):**

```
┌─────────────────────────────────────────────────────┐
│ [Details] [Transactions] [Settings]                  │
├─────────────────────────────────────────────────────┤
│                                                      │
│ Card Transactions - **** 4523                       │
│                                                      │
│ Filter: [Last 30 Days ▼]    [Export ↓]              │
│                                                      │
│ ┌──────────────────────────────────────────────────┐│
│ │ Jan 18, 2026 03:15 PM          -$125.50  ✓      ││
│ │ Amazon.com                                       ││
│ │ Online Purchase • Merchandise                    ││
│ │ TXN-456788                      [Details →]      ││
│ ├──────────────────────────────────────────────────┤│
│ │ Jan 17, 2026 11:20 AM          -$45.00   ✓      ││
│ │ Starbucks #1234                                  ││
│ │ In-Person • Food & Beverage                      ││
│ │ New York, NY, US                [Details →]      ││
│ ├──────────────────────────────────────────────────┤│
│ │ Jan 16, 2026 09:30 AM          -$82.50   ✓      ││
│ │ Uber Trip                                        ││
│ │ Online • Transportation                          ││
│ │ TXN-456785                      [Details →]      ││
│ ├──────────────────────────────────────────────────┤│
│ │ Jan 15, 2026 06:45 PM          -$250.00  ✓      ││
│ │ Best Buy                                         ││
│ │ In-Person • Electronics                          ││
│ │ New York, NY, US                [Details →]      ││
│ └──────────────────────────────────────────────────┘│
│                                                      │
│ [Load More...]                                       │
│                                                      │
│ Total This Period: -$502.00                         │
│ Number of Transactions: 15                           │
└─────────────────────────────────────────────────────┘
```

---

### 3.9 Whitelisted Wallets & Remittance Tab

```
┌───────────────────────────────────────────────────────────────────┐
│ Whitelisted Wallets & Remittance                                   │
├───────────────────────────────────────────────────────────────────┤
│                                                                    │
│ [Crypto Wallets] [Bank Accounts]                                  │
│                                                                    │
│ Whitelisted Crypto Wallet Addresses                  [+ Add New]  │
│                                                                    │
│ ┌────────────────────────────────────────────────────────────────┐│
│ │ ₿ Bitcoin (BTC)                               ✓ Verified       ││
│ │ Label: My Ledger Wallet                                        ││
│ │                                                                ││
│ │ Address: 1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa                    ││
│ │          [Copy 📋] [View on Blockchain →]                      ││
│ │                                                                ││
│ │ Added: Jan 10, 2024                                            ││
│ │ Last Used: Jan 18, 2026 (Withdrawal - 0.005 BTC)              ││
│ │ Total Transfers: 12                                            ││
│ │                                                                ││
│ │ [View History] [Remove]                                        ││
│ └────────────────────────────────────────────────────────────────┘│
│                                                                    │
│ ┌────────────────────────────────────────────────────────────────┐│
│ │ Ξ Ethereum (ETH)                              ✓ Verified       ││
│ │ Label: MetaMask Main                                           ││
│ │                                                                ││
│ │ Address: 0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb0            ││
│ │          [Copy 📋] [View on Blockchain →]                      ││
│ │                                                                ││
│ │ Added: Feb 5, 2024                                             ││
│ │ Last Used: Jan 15, 2026 (Withdrawal - 0.5 ETH)                ││
│ │ Total Transfers: 8                                             ││
│ │                                                                ││
│ │ [View History] [Remove]                                        ││
│ └────────────────────────────────────────────────────────────────┘│
│                                                                    │
│ ┌────────────────────────────────────────────────────────────────┐│
│ │ USDT (TRC20)                                  ⏳ Pending        ││
│ │ Label: Binance Account                                         ││
│ │                                                                ││
│ │ Address: TYDzsYUEpvnYmQk4zGP9JbmEeFCB...                       ││
│ │          [Copy 📋]                                             ││
│ │                                                                ││
│ │ Added: Jan 19, 2026                                            ││
│ │ Status: Pending email verification                             ││
│ │                                                                ││
│ │ [Resend Verification] [Cancel]                                 ││
│ └────────────────────────────────────────────────────────────────┘│
│                                                                    │
└───────────────────────────────────────────────────────────────────┘
```

**Bank Accounts Tab:**

```
┌───────────────────────────────────────────────────────────────────┐
│ Whitelisted Wallets & Remittance                                   │
├───────────────────────────────────────────────────────────────────┤
│                                                                    │
│ [Crypto Wallets] [Bank Accounts]                                  │
│                                                                    │
│ Bank Accounts & Remittance Partners                   [+ Add New]  │
│                                                                    │
│ ┌────────────────────────────────────────────────────────────────┐│
│ │ 🏦 Wells Fargo                                ✓ Verified       ││
│ │ Account Holder: John Michael Doe                               ││
│ │                                                                ││
│ │ Account Number: ****1234                    [Reveal 👁️]        ││
│ │ Routing Number: ****6789                    [Copy 📋]          ││
│ │ Account Type: Checking                                         ││
│ │ Currency: USD                                                  ││
│ │ Country: 🇺🇸 United States                                     ││
│ │                                                                ││
│ │ Added: Jan 15, 2024                                            ││
│ │ Last Used: Jan 19, 2026 (Deposit - $500.00)                   ││
│ │ Total Transfers: 25                                            ││
│ │ Verification Method: Micro-deposit                             ││
│ │                                                                ││
│ │ [View History] [Remove]                                        ││
│ └────────────────────────────────────────────────────────────────┘│
│                                                                    │
│ ┌────────────────────────────────────────────────────────────────┐│
│ │ 🏦 HSBC UK                                    ✓ Verified       ││
│ │ Account Holder: John Doe                                       ││
│ │                                                                ││
│ │ IBAN: GB********************1234             [Reveal] [Copy]   ││
│ │ SWIFT/BIC: HBUKGB4B                          [Copy 📋]         ││
│ │ Account Type: Current Account                                  ││
│ │ Currency: GBP                                                  ││
│ │ Country: 🇬🇧 United Kingdom                                    ││
│ │                                                                ││
│ │ Added: Mar 10, 2024                                            ││
│ │ Last Used: Dec 15, 2025 (Withdrawal - £1,000)                 ││
│ │ Total Transfers: 5                                             ││
│ │ Verification Method: Document upload                           ││
│ │                                                                ││
│ │ [View History] [Remove]                                        ││
│ └────────────────────────────────────────────────────────────────┘│
│                                                                    │
└───────────────────────────────────────────────────────────────────┘
```

---

### 3.10 Security / Login Log Tab

```
┌───────────────────────────────────────────────────────────────────┐
│ Security & Login Log                                               │
├───────────────────────────────────────────────────────────────────┤
│                                                                    │
│ Security Overview                                                  │
│ ┌────────────────────────────────────────────────────────────────┐│
│ │ 2FA Status:          ✓ Enabled (Authenticator App)            ││
│ │ Last Password Change: Dec 10, 2025 (40 days ago)              ││
│ │ Active Sessions:     2 devices                                 ││
│ │ Failed Logins (24h): 0                                         ││
│ │ Security Score:      ✓ Strong (95/100)                        ││
│ └────────────────────────────────────────────────────────────────┘│
│                                                                    │
│ ⚠️  Recent Alerts                                                  │
│ ┌────────────────────────────────────────────────────────────────┐│
│ │ Jan 17, 2026 - 3 failed login attempts from new IP            ││
│ │ IP: 203.0.113.45 (Mumbai, India) - FLAGGED                    ││
│ │ [View Details →]                                               ││
│ └────────────────────────────────────────────────────────────────┘│
│                                                                    │
│ Login History                                                      │
│ Filters: [Status: All ▼] [Date: Last 30 Days ▼]    [Export ↓]    │
│                                                                    │
│ ┌────────────────────────────────────────────────────────────────┐│
│ │ ✓ Successful Login                                             ││
│ │ Jan 19, 2026 09:15 AM                                         ││
│ │                                                                ││
│ │ IP: 203.0.113.10                            🇺🇸                ││
│ │ Location: New York, United States                              ││
│ │ Device: Chrome 120 on macOS 14.2                              ││
│ │ 2FA: ✓ Verified                                                ││
│ │                                                                ││
│ │ Session Active • Last seen: 2 hours ago                        ││
│ │ [Force Logout] [View Session Details]                          ││
│ └────────────────────────────────────────────────────────────────┘│
│                                                                    │
│ ┌────────────────────────────────────────────────────────────────┐│
│ │ ✓ Successful Login                                             ││
│ │ Jan 18, 2026 02:30 PM                                         ││
│ │                                                                ││
│ │ IP: 203.0.113.12                            🇺🇸                ││
│ │ Location: New York, United States                              ││
│ │ Device: Safari on iPhone 15 (iOS 17.2)                        ││
│ │ 2FA: ✓ Verified                                                ││
│ │                                                                ││
│ │ Session Active • Last seen: 3 hours ago                        ││
│ │ [Force Logout] [View Session Details]                          ││
│ └────────────────────────────────────────────────────────────────┘│
│                                                                    │
│ ┌────────────────────────────────────────────────────────────────┐│
│ │ ❌ Failed Login                                  🚩 FLAGGED     ││
│ │ Jan 17, 2026 08:45 PM                                         ││
│ │                                                                ││
│ │ IP: 203.0.113.45                            🇮🇳                ││
│ │ Location: Mumbai, India                                        ││
│ │ Device: Chrome 119 on Windows 11                              ││
│ │ Failure Reason: Invalid password (Attempt 3/3)                 ││
│ │ 2FA: Not reached                                               ││
│ │                                                                ││
│ │ ⚠️  New location and device detected                            ││
│ │ [Block IP] [Add to Watchlist] [Contact Client]                ││
│ └────────────────────────────────────────────────────────────────┘│
│                                                                    │
│ [Load More...]                                                     │
│                                                                    │
│ ┌────────────────────────────────────────────────────────────────┐│
│ │ Security Actions                                               ││
│ │ [🔒 Force Password Reset] [🚫 Block Suspicious IPs]            ││
│ │ [⏏️ Logout All Sessions] [✉️ Send Security Alert]              ││
│ └────────────────────────────────────────────────────────────────┘│
└───────────────────────────────────────────────────────────────────┘
```

---

### 3.11 Audit Log Tab

```
┌───────────────────────────────────────────────────────────────────┐
│ Audit Log                                                          │
├───────────────────────────────────────────────────────────────────┤
│                                                                    │
│ Complete history of all changes made to client account            │
│                                                                    │
│ Filters:                                                           │
│ [Date: Last 30 Days ▼] [Action Type: All ▼] [Agent: All ▼]       │
│ [Changed Field: All ▼] [Search: ___________] [Reset]  [Apply]    │
│                                                         [Export ↓] │
│                                                                    │
│ ┌────────────────────────────────────────────────────────────────┐│
│ │ 346 audit entries found              Showing 1-50 of 346       ││
│ └────────────────────────────────────────────────────────────────┘│
│                                                                    │
│ ┌────────────────────────────────────────────────────────────────┐│
│ │ 🔵 PROFILE UPDATE                                              ││
│ │ Jan 19, 2026 10:45:32 AM                                      ││
│ │                                                                ││
│ │ Field Changed: Phone Number                                    ││
│ │ Old Value: +1 234 567 8900                                     ││
│ │ New Value: +1 234 567 8901                                     ││
│ │                                                                ││
│ │ Reason: Client request - phone number updated                  ││
│ │                                                                ││
│ │ Changed By: Agent Sarah Johnson (ID: CS-4523)                  ││
│ │ Agent IP: 10.0.1.45                                            ││
│ │                                                                ││
│ │ [View Full Details →]                                          ││
│ └────────────────────────────────────────────────────────────────┘│
│                                                                    │
│ ┌────────────────────────────────────────────────────────────────┐│
│ │ ❄️ CARD ACTION                                                 ││
│ │ Jan 18, 2026 03:20:15 PM                                      ││
│ │                                                                ││
│ │ Action: Card Frozen                                            ││
│ │ Card: **** **** **** 8821 (Virtual Card)                      ││
│ │ Previous Status: Active                                        ││
│ │ New Status: Frozen                                             ││
│ │                                                                ││
│ │ Reason: Customer request - suspicious transaction              ││
│ │ Notes: "Client reported unauthorized attempt, froze as         ││
│ │ precaution"                                                    ││
│ │                                                                ││
│ │ Changed By: Agent Mike Chen (ID: CS-7821)                      ││
│ │ Agent IP: 10.0.1.52                                            ││
│ │                                                                ││
│ │ Related Entity: Card ID CARD-8821-VRT                          ││
│ │                                                                ││
│ │ [View Full Details →]                                          ││
│ └────────────────────────────────────────────────────────────────┘│
│                                                                    │
│ ┌────────────────────────────────────────────────────────────────┐│
│ │ 🏆 ACCOUNT TIER CHANGE                                         ││
│ │ Mar 1, 2025 11:30:00 AM                                       ││
│ │                                                                ││
│ │ Field Changed: Account Tier                                    ││
│ │ Old Value: Silver                                              ││
│ │ New Value: Gold                                                ││
│ │                                                                ││
│ │ Triggered By: Automatic (Balance threshold met)                ││
│ │ Account Balance: $25,450.00 (Threshold: $25,000)              ││
│ │                                                                ││
│ │ Changed By: System (Auto-upgrade)                              ││
│ │                                                                ││
│ │ [View Full Details →]                                          ││
│ └────────────────────────────────────────────────────────────────┘│
│                                                                    │
│ ┌────────────────────────────────────────────────────────────────┐│
│ │ 🔐 PASSWORD RESET                                              ││
│ │ Dec 10, 2025 09:15:42 AM                                      ││
│ │                                                                ││
│ │ Action: Password Reset Requested                               ││
│ │ Method: CS Agent initiated                                     ││
│ │                                                                ││
│ │ Reason: Client forgot password                                 ││
│ │ Notes: "Client verified via phone, sent reset link"           ││
│ │                                                                ││
│ │ Changed By: Agent Sarah Johnson (ID: CS-4523)                  ││
│ │ Agent IP: 10.0.1.45                                            ││
│ │                                                                ││
│ │ Reset Email Sent: ✓ Yes (dec...@email.com)                    ││
│ │ Password Changed: ✓ Yes (Dec 10, 2025 09:32 AM)              ││
│ │                                                                ││
│ │ [View Full Details →]                                          ││
│ └────────────────────────────────────────────────────────────────┘│
│                                                                    │
│ ┌────────────────────────────────────────────────────────────────┐│
│ │ 💰 MANUAL BALANCE ADJUSTMENT                                   ││
│ │ Nov 5, 2025 02:45:18 PM                                       ││
│ │                                                                ││
│ │ Currency: USD                                                  ││
│ │ Adjustment: +$150.00                                           ││
│ │ Previous Balance: $5,100.00                                    ││
│ │ New Balance: $5,250.00                                         ││
│ │                                                                ││
│ │ Reason: Compensation                                           ││
│ │ Notes: "Service compensation for delayed card delivery"       ││
│ │ Reference: TICKET-12345                                        ││
│ │                                                                ││
│ │ Changed By: Agent Sarah Johnson (ID: CS-4523)                  ││
│ │ Approved By: Manager Tom Williams (ID: MGR-001)                ││
│ │ Agent IP: 10.0.1.45                                            ││
│ │                                                                ││
│ │ [View Full Details →]                                          ││
│ └────────────────────────────────────────────────────────────────┘│
│                                                                    │
│ [Load More...]                                    [1][2][3]...    │
└───────────────────────────────────────────────────────────────────┘
```

---

## 4. Component Specifications

### 4.1 Status Badges

```
Active:     🟢 Active     (Green background, white text)
Pending:    🟡 Pending    (Amber background, dark text)
Suspended:  🔴 Suspended  (Red background, white text)
Frozen:     🔵 Frozen     (Blue background, white text)
Completed:  ✓ Completed   (Green with checkmark)
Failed:     ❌ Failed     (Red with X)
Processing: ⏳ Processing (Blue with spinner)
```

### 4.2 Action Buttons

```
Primary:    Blue background (#0066FF), white text, medium shadow
Secondary:  White background, gray border, gray text
Danger:     Red background (#F44336), white text
Success:    Green background (#00C853), white text
Ghost:      Transparent, blue text, no border

Sizes:
- Small:  32px height, 12px font
- Medium: 40px height, 14px font (default)
- Large:  48px height, 16px font
```

### 4.3 Form Inputs

```
Text Input:
- Height: 40px
- Padding: 12px 16px
- Border: 1px solid #BDBDBD
- Border radius: 8px
- Focus: Blue border (#0066FF), shadow

Dropdown:
- Same as text input
- Arrow icon on right
- Dropdown menu: white background, shadow

Date Picker:
- Same as text input
- Calendar icon on right
- Popup calendar overlay
```

### 4.4 Cards

```
Standard Card:
- Background: White (#FFFFFF)
- Border: 1px solid #E0E0E0
- Border radius: 12px
- Padding: 24px
- Shadow: 0 2px 8px rgba(0,0,0,0.05)
- Hover: Lift effect (shadow increase)
```

### 4.5 Tables

```
Header:
- Background: #F5F5F5
- Font: 12px, Semi-bold, uppercase
- Padding: 12px 16px

Row:
- Background: White
- Border bottom: 1px solid #E0E0E0
- Padding: 16px
- Hover: #FAFAFA background

Alternating rows for better readability
```

---

## 5. Interaction Patterns

### 5.1 Modal Usage

**When to use:**
- Actions requiring confirmation (freeze card, delete, suspend account)
- Forms that need full attention (manual balance adjustment)
- Critical warnings or alerts
- Quick data entry (add note, send email)

**Behavior:**
- Overlay darkens background (60% opacity black)
- Modal centered on screen
- Click outside or ESC to close (with confirmation if data entered)
- Max width: 600px
- Includes close X button top-right

### 5.2 Drawer Usage

**When to use:**
- Viewing detailed information without losing context
- Forms with multiple sections
- Supplementary information related to main view
- Transaction details, card details, balance history

**Behavior:**
- Slides in from right (or left for side panel)
- Width: 400-600px depending on content
- Overlay dimmed background (30% opacity)
- Click outside to close
- Scroll if content exceeds viewport

### 5.3 Side Panel Usage

**When to use:**
- Persistent supplementary information
- Quick reference data (recent clients, notes)
- Navigation assistance
- Filter panels

**Behavior:**
- Fixed position (left or right)
- Can be collapsed/expanded
- No overlay (part of layout)
- Smooth transition animation

### 5.4 Inline Expansion

**When to use:**
- Additional details within lists
- Secondary information that's not always needed
- Keeping user in flow without page change

**Behavior:**
- Smooth expand/collapse animation
- Arrow icon indicates state
- Expanded area clearly distinct (background or border)

### 5.5 Toast Notifications

**When to use:**
- Success confirmations ("Card frozen successfully")
- Error messages ("Failed to update information")
- Info alerts ("Client has logged in")
- Warning messages

**Behavior:**
- Appears top-right corner
- Auto-dismiss after 5 seconds (info/success) or 10 seconds (error/warning)
- Dismissible with X button
- Stack if multiple notifications
- Icon + color coding by type

### 5.6 Loading States

```
Page Load:      Full-page spinner with logo
Button Click:   Button shows spinner, disabled state
Data Fetch:     Skeleton loaders (gray animated blocks)
Table Load:     Progress bar at top
```

### 5.7 Empty States

```
No Data:        Icon + "No data available" + action button (if applicable)
No Results:     "No results found for [query]" + clear filters button
Error State:    Error icon + message + retry button
```

---

## 6. Responsive Behavior

### 6.1 Desktop (1920x1080 - Primary)

- Full sidebar visible (240px)
- Content area: Remaining width
- Cards in grid layout (2-3 columns)
- Drawers: 600px width
- Modals: 600px max width

### 6.2 Laptop (1366x768 - Secondary)

- Sidebar collapsible to icon-only (64px)
- Content area: Remaining width
- Cards in grid layout (2 columns)
- Drawers: 500px width
- Modals: 500px max width
- Slightly reduced padding/spacing

### 6.3 Tablet (1024x768 - Tertiary)

- Sidebar hidden by default (hamburger menu)
- Full-width content
- Cards in single column
- Drawers: 80% width
- Modals: 90% width

### 6.4 Mobile (Not Priority for Phase 1)

- Out of scope
- If accessed, show message: "Please use desktop for best experience"
- Critical read-only views only

---

## 7. Accessibility

### 7.1 Keyboard Navigation

- Tab through all interactive elements
- Enter to activate buttons/links
- Space to toggle checkboxes
- Arrow keys for dropdown navigation
- ESC to close modals/drawers

### 7.2 Screen Reader Support

- Semantic HTML (nav, main, article, section)
- ARIA labels for icon buttons
- Alt text for images
- Proper heading hierarchy
- Focus indicators visible

### 7.3 Color Contrast

- Minimum 4.5:1 for normal text
- Minimum 3:1 for large text
- Status not conveyed by color alone (icons + text)

---

## 8. Dark Mode (Optional for Phase 1)

```
Background:      #1E1E1E
Cards:           #2A2A2A
Text Primary:    #FFFFFF
Text Secondary:  #B0B0B0
Borders:         #3A3A3A
Primary Blue:    #4D94FF (lighter)
```

---

## 9. Animation & Transitions

### 9.1 Transition Durations

```
Instant:  0ms     (color changes, text updates)
Fast:     150ms   (hover effects, button clicks)
Normal:   300ms   (drawers, modals, expansions)
Slow:     500ms   (page transitions, complex animations)
```

### 9.2 Easing Functions

```
Standard: ease-in-out (most transitions)
Entrance: ease-out (modals, drawers appearing)
Exit:     ease-in (modals, drawers closing)
```

---

## 10. Design Assets

### 10.1 Iconography

- Icon set: Heroicons or Material Icons
- Size: 20px (small), 24px (medium), 32px (large)
- Stroke width: 2px
- Style: Outline for UI, Solid for emphasis

### 10.2 Illustrations

- Empty states: Simple line illustrations
- Error states: Friendly character illustrations
- Onboarding: Instructional illustrations
- Style: Modern, minimal, consistent

---

## 11. Implementation Notes

### 11.1 Component Library Recommendation

**Option A: Material-UI (MUI)**
- Pros: Comprehensive, well-documented, matches design system
- Cons: Larger bundle size
- Best for: Quick development, consistent look

**Option B: Ant Design**
- Pros: Excellent table/form components, enterprise focus
- Cons: Opinionated styling
- Best for: Data-heavy applications (fits CS portal perfectly)

**Option C: Chakra UI**
- Pros: Highly customizable, great accessibility, smaller bundle
- Cons: Less enterprise components out-of-box
- Best for: Custom design with flexibility

**Recommendation:** Ant Design for Phase 1 (excellent for internal tools)

### 11.2 State Management

- Use Redux Toolkit or Zustand for global state
- React Query for server state management
- Local state for UI-only interactions

### 11.3 Performance Optimization

- Lazy load tabs/sections
- Virtual scrolling for long lists (transaction history)
- Debounce search inputs
- Optimize images/icons
- Code splitting by route

---

**Design Version:** 1.0
**Last Updated:** January 19, 2026
**Next Review:** Upon development start

---

## Appendix: Quick Reference

### Color Codes
```
Primary: #0066FF
Success: #00C853
Warning: #FFA000
Error:   #F44336
Gray-900: #1A1A1A
White:   #FFFFFF
```

### Spacing
```
xs: 4px, sm: 8px, md: 16px, lg: 24px, xl: 32px
```

### Font Sizes
```
H1: 32px, H2: 24px, H3: 20px, Body: 14px, Caption: 11px
```
